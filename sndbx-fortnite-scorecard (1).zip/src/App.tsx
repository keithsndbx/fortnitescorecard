// Paste your full FortniteScoreApp component code here
